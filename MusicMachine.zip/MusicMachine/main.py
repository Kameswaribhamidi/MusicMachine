from bs4 import BeautifulSoup
import requests as re
import spotipy
from spotipy.oauth2 import SpotifyOAuth

# Asking user for data
spotify_client_id = input("Enter your spoify client id: ")
spotify_client_secret = input("Enter your spoify client secret: ")
date = input("Which year you want to travel to? Type the date in thie format YYYY-MM-DD:   ")

#Getting the HTML script of BB Hot 100 of entered date
response = re.get("https://www.billboard.com/charts/hot-100/" + date)
# Creating soup
soup = BeautifulSoup(response.text, "html.parser")
# Extracting the song names from the BB chart
song_spans = soup.select("li ul li h3")
song_names = [song.getText().strip() for song in song_spans]

# working with spotipy
sp = spotipy.Spotify(
    auth_manager=SpotifyOAuth(
        client_id=spotify_client_id,
        client_secret=spotify_client_secret,
        redirect_uri="http://example.com",
        scope="playlist-modify-private",
        show_dialog=True,
        cache_path="MusicMachine/token.txt",
        username="KAM",
    )
)

# getting user id
user_id = sp.current_user()["id"]
#Creating list of URIs for BB chart
songs_uris = []
year = date.split("-")[0]
for song in song_names:
    result = sp.search(q=f"track: {song} year: {year}", type="track")
    try:
        uri = result["tracks"]["items"][0]["uri"]
        songs_uris.append(uri)
    except IndexError:
        print(f"{song} doesn't exist in Spotify. Skipped.")
        
# Creating a playlist 
new_pl = sp.user_playlist_create(user_id, f"{date} Billboard 100", public=False)
adding_songs = sp.user_playlist_add_tracks(user_id, playlist_id=new_pl["id"], tracks=songs_uris)

# The new playlist will be added in your spotify "playlists"